package com.safestyle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafestyleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafestyleApplication.class, args);
	}

}
